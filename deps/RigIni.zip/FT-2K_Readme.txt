FT-2KAFSKPEPV3.ini, FT-2KFSKPEPV3.ini

Here is what you do:

1) Copy the attached files into Program Files/Afreet/Omnirig/Rigs folder
2) Depending if you use FSK or AFSK, you will open Bandmaster then Tools
then Settings then Miscellaneous
Click on Configure and select from the list of INI files either of the 2 INI
files that I just supplied, depending on if you are using FSK or AFSK
Then you are ready to go.
Restart Bandmaster just to be sure that the selection workd.
Now when you click on a cluster spot SPLIT operation, the VFO B should
follow VFO A in Mode , ie., SSB should be on both VFOs or CW or RTTY /
PAcket depending the mode listed in Bandmaster spot.

Dan Schaaf